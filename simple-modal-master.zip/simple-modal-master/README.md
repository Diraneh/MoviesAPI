# simple-modal
A simple javascript modal library

Official Documentation http://www.simplemodal.xyz/

Install with bower

```
bower install simple-modal
```
